# coding = utf-8
# author:lifangyi
# date: 2019/5/27 下午3:31
# file: __init__.py.py

from bovine_picker import picker