bovine-picker

1.a test lib/project of pypi distribution process.

2.a simple usage of Bovine Birthday formula. 

3.check out what day of a week with birthday as parameter in three languages:Simplified Chinese, English, Japanese.

4.Only date after AD 1582.10.15 is verified and valid.

5.MIT License.

